<?php

namespace sample;
class calculator{


    function calculate($a,$b){


        $c=$a+$b;
        echo $c;

    }
}



?>