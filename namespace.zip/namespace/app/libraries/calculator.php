<?php

namespace app\libraries;
class calculator{


    function calculate($a,$b){


        $c=$a+$b;
        echo $c;

    }
}



?>